function install
% Generated with Toolbox Extender https://github.com/ETMC-Exponenta/ToolboxExtender
dev = IconsDev;
dev.test('', false);
% Post-install commands
cd('..');
ext = IconsExtender;
ext.doc;
% Add your post-install commands below
IconsApp